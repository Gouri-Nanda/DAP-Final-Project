# data_analysis_app/views.py
import os
from django.shortcuts import render, HttpResponse
from data_analysis_project import settings 
import pandas as pd
from ydata_profiling import ProfileReport
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
from io import BytesIO
import base64
from io import StringIO
import pickle
import numpy as np
import matplotlib.pyplot as plt
import plotly.offline as po
import plotly.graph_objs as go
from sklearn.preprocessing import StandardScaler




def data_tab(request):
    # Read Titanic dataset from CSV
    df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")
 # Get the first ten rows of the dataset
    df_first_ten = df.head(10)
    df_last_ten = df.tail(10)

    # Get information about the columns (data types, non-null counts, null counts)
    columns_info = pd.DataFrame({
        'Column Name': df.columns,
        'Data Type': df.dtypes,
        'Non-Null Count': df.notnull().sum(),
        'Null Count': df.isnull().sum()
    })

    # Convert DataFrame to HTML for rendering in template
    table_html1 = df_first_ten.to_html(classes='table table-hover table-bordered')
    table_html2 = df_last_ten.to_html(classes='table table-hover table-bordered')

    # Include the columns information in the HTML template
    columns_info_html = f"{columns_info.to_html(classes='table table-hover table-bordered', index=False)}"

    return render(request, 'data_tab.html', {'table_html1': table_html1, 'table_html2':table_html2, 'columns_info_html': columns_info_html})



def profile_view(request):
    df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")

    # Create a profile report
    profile = ProfileReport(df, title="Pandas Profiling Report")
    
    print('Setting Dir Path')
    print(settings.TEMPLATE_DIR)
    templates_dir = settings.TEMPLATE_DIR
    report_path = os.path.join(templates_dir, 'report.html')

    # Save the report to the templates directory
    profile.to_file(report_path)
    # Pass the HTML file path to the template

    return render(request, 'report.html', {'report_path': report_path})


  
def descriptive_statistics_tab(request):
    # Read Titanic dataset from CSV
    df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")
    
    # Perform descriptive statistics using pandas
    descriptive_stats = df.describe().to_html(classes='table table-bordered table-hover')

    return render(request, 'descriptive_statistics_tab.html', {'descriptive_stats': descriptive_stats})


df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")
heart=df[df['HadHeartAttack']=='Yes']
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.graph_objects as go
def exploratory_data_analysis_tab(request):
    # Replace values in the 'heart' DataFrame
    heart.replace({'Yes': 1, 'No': 0}, inplace=True)                 
    heart['TetanusLast10Tdap'] = heart['TetanusLast10Tdap'].replace({
        'Yes, received Tdap': 1,
        'No, did not receive any tetanus shot in the past 10 years': 0,
        'Yes, received tetanus shot but not sure what type': 1,
        'Yes, received tetanus shot, but not Tdap': 1
    })

    # Define the columns to plot
    vaccine_columns = ['FluVaxLast12', 'PneumoVaxEver', 'TetanusLast10Tdap']

    # Define custom colors for each condition
    colors = ['rgba(255, 102, 102, 0.7)', 'rgba(102, 255, 102, 0.7)', 'rgba(102, 102, 255, 0.7)']

    # Create a subplot
    fig = make_subplots(rows=1, cols=1, subplot_titles=['Vaccination Status and Heart Attack'])

    # Create a dropdown menu for selecting the condition
    dropdown_menu = [
        {'label': vaccine, 'method': 'update', 'args': [{'visible': [c == vaccine for c in vaccine_columns]}]}
        for vaccine in vaccine_columns
    ]

    # Create traces for each condition
    traces = []
    for i, vaccine in enumerate(vaccine_columns):
        trace = go.Pie(
            labels=['Vaccinated', 'Not Vaccinated'],
            values=heart[vaccine].value_counts().values,
            name=vaccine,
            hoverinfo='label+percent+value',
            marker=dict(colors=[colors[i], '#ff9900']),  # Light gray color for "Not Vaccinated"
        )
        traces.append(trace)

    # Add traces to the subplot
    for trace in traces:
        fig.add_trace(trace)

    # Update layout with dropdown menu
    fig.update_layout(
        updatemenus=[{'active': 0, 'buttons': dropdown_menu, 'direction': 'down', 'showactive': True}],
        title='Vaccination Status and Heart Attack',
    )

    # Convert the Plotly figure to HTML
    plot_html = fig.to_html(full_html=False)

    

    # Define the columns to plot
    selected_columns = ['HadAngina', 'HadCOPD', 'HadDepressiveDisorder', 'HadArthritis',
                        'HadStroke', 'HadAsthma', 'HadSkinCancer', 'HadKidneyDisease']

    # Define custom colors for each condition
    colors = ['rgba(78, 121, 167, 0.7)', 'rgba(242, 142, 43, 0.7)', 'rgba(225, 87, 89, 0.7)', 'rgba(118, 183, 178, 0.7)',
            'rgba(89, 106, 110, 0.7)', 'rgba(200, 82, 0, 0.7)', 'rgba(111, 145, 160, 0.7)', 'rgba(179, 120, 101, 0.7)']

    # Create a subplot
    fig2 = make_subplots(rows=1, cols=1)

    # Create a dropdown menu for selecting the condition
    dropdown_menu = [
        {'label': condition, 'method': 'update', 'args': [{'visible': [c == condition for c in selected_columns]}]}
        for condition in selected_columns
    ]

    # Create traces for each condition
    traces = []
    for i, condition in enumerate(selected_columns):
        trace = go.Bar(
            x=['Has Not ' + condition, condition],
            y=heart[condition].value_counts().values,
            textposition='auto',
            name=condition,
            marker=dict(color=colors[i]),width=0.8
        )
        traces.append(trace)

    # Add traces to the subplot
    for trace in traces:
        fig2.add_trace(trace)

    # Update layout with dropdown menu
    fig2.update_layout(
        updatemenus=[{'active': 0, 'buttons': dropdown_menu, 'direction': 'down', 'showactive': True}],
        xaxis=dict(title='Condition'),
        yaxis=dict(title='Count'),
        title='Distribution of Conditions',
    )
    plot_html2 = fig2.to_html(full_html=False)

    heart['SmokerStatus'].replace({'Current smoker - now smokes every day': 'Regular Smoker ', 'Current smoker - now smokes some days': 'Occasional Smoker'}, inplace=True)
    heart['ECigaretteUsage'].replace({'Never used e-cigarettes in my entire life': 'Never', 'Use them some days': 'Occasional Smoker','Not at all (right now)':'Former Smoker','Use them every day':'Current Smoker'}, inplace=True)

    count_smoker = heart['SmokerStatus'].value_counts()
    data_for_plotly = pd.DataFrame({'SmokerStatus': count_smoker.index, 'Count': count_smoker.values})

    custom_colors = ['#99FF99','#66B2FF', '#FFD700','#FF9999']

    fig3 = px.pie(data_for_plotly, names='SmokerStatus', values='Count', hole=0.5, title='Smoker Status for Heart Disease',color_discrete_sequence=custom_colors)

    fig3.update_layout(
        title_font=dict(size=20),
        showlegend=False,
    )
    plot_html3 = fig3.to_html(full_html=False)


    heart['HadHeartAttack'] = pd.to_numeric(heart['HadHeartAttack'], errors='coerce')

    fig4 = px.density_heatmap(
        heart,
        x='HeightInMeters',
        y='WeightInKilograms',
        z='HadHeartAttack',
        labels={'HadHeartAttack': 'Heart Attack'},
        title='Relationship between Height, Weight, and Heart Attacks'
    )

    fig4.update_layout(
        xaxis_title='Height (meters)',
        yaxis_title='Weight (kilograms)',
    )
    plot_html4 = fig4.to_html(full_html=False)

    # Define the columns to plot
    selected_cond = ['DeafOrHardOfHearing', 'BlindOrVisionDifficulty',
        'DifficultyConcentrating', 'DifficultyWalking',
        'DifficultyDressingBathing', 'DifficultyErrands']

    # Define custom colors for each condition
    colors = ['rgba(51, 153, 153, 0.7)', 'rgba(147, 170, 204, 0.7)', 'rgba(153, 200, 200, 0.7)', 'rgba(230, 126, 34, 0.7)',
            'rgba(238, 207, 174, 0.7)', 'rgba(242, 221, 170, 0.7)']

    # Create a subplot
    fig5 = make_subplots(rows=1, cols=1)

    # Create a dropdown menu for selecting the condition
    dropdown_menu1 = [
        {'label': cond, 'method': 'update', 'args': [{'visible': [c == cond for c in selected_cond]}]}
        for cond in selected_cond
    ]
    # Create traces for each condition
    traces1 = []
    for i, cond in enumerate(selected_cond):
        trace = go.Bar(
            x=['No ' + cond, cond],
            y=heart[cond].value_counts().values,
            textposition='auto',
            name=cond,
            marker=dict(color=colors[i])
        )
        traces1.append(trace)

    # Add traces to the subplot
    for trace in traces1:
        fig5.add_trace(trace)

    # Update layout with dropdown menu
    fig5.update_layout(
        updatemenus=[{'active': 0, 'buttons': dropdown_menu1, 'direction': 'down', 'showactive': True}],
        xaxis=dict(title='Condition'),
        yaxis=dict(title='Count'),
        title='Distribution of Abilities',
    )
    plot_html5 = fig5.to_html(full_html=False)

    # Define the columns to plot
    selected_columns = ["RaceEthnicityCategory", "State"]

    # Define custom colors for each condition
    colors = ['rgba(119, 0, 0, 0.7)', 'rgba(0, 77, 64, 0.7)']

    # Create a subplot
    fig6 = make_subplots(rows=1, cols=1)

    # Create a dropdown menu for selecting the condition
    dropdown_menu2 = [
        {
            "label": condition,
            "method": "update",
            "args": [{
                "visible": [c == condition for c in selected_columns]
            }],
        }
        for condition in selected_columns
    ]

    dropdown_y_position = 1.1
    # Create traces for each condition
    traces2 = []
    for i, condition in enumerate(selected_columns):
        # Sort values and index in ascending order
        values = heart[condition].value_counts().values[::-1]
        index = heart[condition].value_counts().index[::-1]

        trace = go.Bar(
            x=values,
            y=index,
            orientation="h",  # Set the orientation to horizontal
            textposition="auto",
            name=condition,
            marker=dict(color=colors[0]),
        )
        traces2.append(trace)

    # Add traces to the subplot
    for trace in traces2:
        fig6.add_trace(trace)
    fig6.update_layout(
    updatemenus=[
        {
            "y": dropdown_y_position,
            "active": 1,
            "buttons": dropdown_menu2,
            "direction": "down",
            "showactive": True,
        }
    ],
    yaxis=dict(title="State / Race"),  
    xaxis=dict(title="Count"),
    title="Heart Attacks by State and Race",)
    plot_html6 = fig6.to_html(full_html=False)











    return render(request, 'exploratory_data_analysis_tab.html', {'plot_html': plot_html,'plot_html2': plot_html2,'plot_html3':plot_html3,'plot_html4':plot_html4,'plot_html5':plot_html5,'plot_html6':plot_html6})


    




def export_to_csv(request):
    # Read Titanic dataset from CSV
    df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")

    # Generate CSV file
    csv_file = df.to_csv(index=False)

    # Create HTTP response with CSV file
    response = HttpResponse(csv_file, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="titanic_data.csv"'
    
    return response


def export_to_excel(request):
    # Read Titanic dataset from CSV
    df = pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")

    # Generate Excel file
    excel_file = BytesIO()
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    excel_file.seek(0)

    # Create HTTP response with Excel file
    response = HttpResponse(excel_file.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="titanic_data.xlsx"'

    return response

def predict_risk(request):
    #loading the model from pickle file
    if request.method == 'POST':
        model_filename = 'heart_model.pkl'
        model_path = os.path.join(os.path.dirname(__file__), 'models', model_filename)
        with open(model_path, 'rb') as model_file:
            model = pickle.load(model_file)
        #getting the input values
        physical_health_days = float(request.POST.get('physicaldays'))
        mental_health_days = float(request.POST.get('mentaldays'))
        height = float(request.POST.get('height'))
        weight = float(request.POST.get('height'))
        sleep_hours = float(request.POST.get('sleephours'))
        BMI= (weight)/(height**2)
        standardScaler = StandardScaler()
        features = [[physical_health_days, mental_health_days, sleep_hours, height, weight, BMI]]
        features = standardScaler.fit_transform(features)
        #making it into the required form for prediction
        Sex_Male = 1 if request.POST.get('sex') else 0
        GeneralHealth_Fair = 1 if request.POST.get('generalhealth')=='Fair' else 0
        GeneralHealth_Good = 1 if request.POST.get('generalhealth')=='Good' else 0
        GeneralHealth_Poor = 1 if request.POST.get('generalhealth')=='Poor' else 0
        GeneralHealth_Very_good = 1 if request.POST.get('generalhealth')=='Very Good' else 0
        LastCheckupTime_Within_past_2_years_1_year_but_less_than_2_years_ago = 1 if request.POST.get('checkup')== 'Within past 2 years (1 year but less than 2 years ago' else 0
        LastCheckupTime_Within_past_5_years_2_years_but_less_than_5_years_ago = 1 if request.POST.get('checkup')== 'Within past 5 years (2 years but less than 5 years ago)?' else 0
        LastCheckupTime_Within_past_year_anytime_less_than_12_months_ago =  1 if request.POST.get('checkup')== 'Within past year (anytime less than 12 months ago)' else 0
        PhysicalActivities_Yes = 1 if request.POST.get('physicalactivities')=='Yes' else 0
        RemovedTeeth_6_or_more_but_not_all = 1 if request.POST.get('teeth')=='6 or more, but not all' else 0
        RemovedTeeth_All = 1 if request.POST.get('teeth')=='All' else 0
        RemovedTeeth_None_of_them = 1 if request.POST.get('teeth')=='None of them' else 0
        HadAngina_Yes  = 1 if request.POST.get('HadAngina')=='Yes' else 0
        HadStroke_Yes= 1 if request.POST.get('HadStroke')=='Yes' else 0
        HadAsthma_Yes= 1 if request.POST.get('HadAsthma')=='Yes' else 0
        HadSkinCancer_Yes = 1 if request.POST.get('HadSkinCancer')=='Yes' else 0
        HadCOPD_Yes = 1 if request.POST.get('HadCOPD')=='Yes' else 0
        HadDepressiveDisorder_Yes = 1 if request.POST.get('HadDepressiveDisorder')=='Yes' else 0
        HadKidneyDisease_Yes = 1 if request.POST.get('HadKidneyDisease')=='Yes' else 0
        HadArthritis_Yes = 1 if request.POST.get('HadArthritis')=='Yes' else 0
        HadDiabetes_No_pre_diabetes_or_borderline_diabetes = 1 if request.POST.get('HadDiabetes')=='No, pre-diabetes or borderline diabetes' else 0
        HadDiabetes_Yes = 1 if request.POST.get('HadDiabetes')=='Yes' else 0
        HadDiabetes_Yes_but_only_during_pregnancy_female = 1 if request.POST.get('HadDiabetes')=='Yes, but only during pregnancy (female)' else 0
        DeafOrHardOfHearing_Yes  = 1 if request.POST.get('DeafOrHardOfHearing')=='Yes' else 0
        BlindOrVisionDifficulty_Yes  = 1 if request.POST.get('BlindOrVisionDifficulty')=='Yes' else 0
        DifficultyConcentrating_Yes  = 1 if request.POST.get('DifficultyConcentrating')=='Yes' else 0
        DifficultyWalking_Yes = 1 if request.POST.get('DifficultyWalking')=='Yes' else 0
        DifficultyDressingBathing_Yes    = 1 if request.POST.get('DifficultyDressingBathing')=='Yes' else 0
        DifficultyErrands_Yes  = 1 if request.POST.get('DifficultyErrands')=='Yes' else 0
        SmokerStatus_Current_smoker_now_smokes_some_days  = 1 if request.POST.get('SmokerStatus')=='Current smoker - now smokes some days' else 0
        SmokerStatus_Former_smoker = 1 if request.POST.get('SmokerStatus')=='Former smoker' else 0
        SmokerStatus_Never_smoked = 1 if request.POST.get('SmokerStatus')=='Never smoked' else 0 
        ECigaretteUsage_Not_at_all_right_now= 1 if request.POST.get('ECigaretteUsage')=='Not at all (right now)' else 0
        ECigaretteUsage_Use_them_every_day = 1 if request.POST.get('ECigaretteUsage')=='Use them every day' else 0
        ECigaretteUsage_Use_them_some_days = 1 if request.POST.get('ECigaretteUsage')=='Use them some days' else 0 
        ChestScan_Yes  = 1 if request.POST.get('ChestScan')=='Yes' else 0
        RaceEthnicityCategory_Hispanic  = 1 if request.POST.get('RaceEthnicityCategory')=='Hispanic' else 0
        RaceEthnicityCategory_Multiracial_Non_Hispanic  = 1 if request.POST.get('RaceEthnicityCategory')=='Multiracial, Non-Hispanic' else 0
        RaceEthnicityCategory_Other_race_only_Non_Hispanic  = 1 if request.POST.get('RaceEthnicityCategory')=='Other race only, Non-Hispanic' else 0
        RaceEthnicityCategory_White_only_Non_Hispanic   = 1 if request.POST.get('RaceEthnicityCategory')=='White only, Non-Hispanic' else 0
        AgeCategory_Age_25_to_29  = 1 if request.POST.get('AgeCategory')=='Age 25 to 29' else 0
        AgeCategory_Age_30_to_34  = 1 if request.POST.get('AgeCategory')=='Age 30 to 34' else 0
        AgeCategory_Age_35_to_39  = 1 if request.POST.get('AgeCategory')=='Age 35 to 39' else 0
        AgeCategory_Age_40_to_44  = 1 if request.POST.get('AgeCategory')=='Age 40 to 44' else 0
        AgeCategory_Age_45_to_49  = 1 if request.POST.get('AgeCategory')=='Age 45 to 49' else 0
        AgeCategory_Age_50_to_54  = 1 if request.POST.get('AgeCategory')=='Age 50 to 54' else 0
        AgeCategory_Age_55_to_59  = 1 if request.POST.get('AgeCategory')=='Age 55 to 59' else 0
        AgeCategory_Age_60_to_64  = 1 if request.POST.get('AgeCategory')=='Age 60 to 64' else 0
        AgeCategory_Age_65_to_69  = 1 if request.POST.get('AgeCategory')=='Age 65 to 69' else 0
        AgeCategory_Age_70_to_74  = 1 if request.POST.get('AgeCategory')=='Age 70 to 74' else 0
        AgeCategory_Age_75_to_79  = 1 if request.POST.get('AgeCategory')=='Age 75 to 79' else 0
        AgeCategory_Age_80_or_older  = 1 if request.POST.get('AgeCategory')=='Age 80 or older' else 0
        AlcoholDrinkers_Yes  = 1 if request.POST.get('AlcoholDrinkers')=='Yes' else 0
        HIVTesting_Yes = 1 if request.POST.get('HIVTesting')=='Yes' else 0
        FluVaxLast12_Yes = 1 if request.POST.get('FluVaxLast12')=='Yes' else 0
        PneumoVaxEver_Yes  = 1 if request.POST.get('PneumoVaxEver')=='Yes' else 0
        HighRiskLastYear_Yes  = 1 if request.POST.get('HighRiskLastYear')=='Yes' else 0
        CovidPos_Tested_positive_using_home_test_without_a_health_professional = 1 if request.POST.get('CovidPos')=='Tested positive using home test without a health professional' else 0
        CovidPos_Yes  = 1 if request.POST.get('CovidPos')=='Yes' else 0
        #feeding the data to the model
        x=[features[0][0],features[0][1],features[0][2],features[0][3],features[0][4],features[0][5],Sex_Male, GeneralHealth_Fair, GeneralHealth_Good, GeneralHealth_Poor, GeneralHealth_Very_good,
                            LastCheckupTime_Within_past_2_years_1_year_but_less_than_2_years_ago,
                            LastCheckupTime_Within_past_5_years_2_years_but_less_than_5_years_ago,
                            LastCheckupTime_Within_past_year_anytime_less_than_12_months_ago, PhysicalActivities_Yes,
                            RemovedTeeth_6_or_more_but_not_all, RemovedTeeth_All, RemovedTeeth_None_of_them, HadAngina_Yes,HadStroke_Yes,
                            HadAsthma_Yes, HadSkinCancer_Yes, HadCOPD_Yes, HadDepressiveDisorder_Yes,HadKidneyDisease_Yes, HadArthritis_Yes, 
                            HadDiabetes_No_pre_diabetes_or_borderline_diabetes,HadDiabetes_Yes, HadDiabetes_Yes_but_only_during_pregnancy_female,
                            DeafOrHardOfHearing_Yes,BlindOrVisionDifficulty_Yes, DifficultyConcentrating_Yes, DifficultyWalking_Yes,
                            DifficultyDressingBathing_Yes, DifficultyErrands_Yes, SmokerStatus_Current_smoker_now_smokes_some_days,
                            SmokerStatus_Former_smoker, SmokerStatus_Never_smoked, ECigaretteUsage_Not_at_all_right_now,
                            ECigaretteUsage_Use_them_every_day,ECigaretteUsage_Use_them_some_days, ChestScan_Yes,
                            RaceEthnicityCategory_Hispanic, RaceEthnicityCategory_Multiracial_Non_Hispanic,
                            RaceEthnicityCategory_Other_race_only_Non_Hispanic, RaceEthnicityCategory_White_only_Non_Hispanic,
                            AgeCategory_Age_25_to_29, AgeCategory_Age_30_to_34, AgeCategory_Age_35_to_39, AgeCategory_Age_40_to_44,
                            AgeCategory_Age_45_to_49, AgeCategory_Age_50_to_54, AgeCategory_Age_55_to_59, AgeCategory_Age_60_to_64,
                            AgeCategory_Age_65_to_69, AgeCategory_Age_70_to_74, AgeCategory_Age_75_to_79, AgeCategory_Age_80_or_older,
                            AlcoholDrinkers_Yes, HIVTesting_Yes, FluVaxLast12_Yes, PneumoVaxEver_Yes, HighRiskLastYear_Yes,
                            CovidPos_Tested_positive_using_home_test_without_a_health_professional, CovidPos_Yes]
        #getting the predicted probability
        prediction = model.predict_proba([x])[:, 1] * 100
        prediction=prediction[0]
        return render(request, 'prediction_result.html', {'prediction': prediction})
    return render(request,'predict_risk.html',{'prediction':None})
    