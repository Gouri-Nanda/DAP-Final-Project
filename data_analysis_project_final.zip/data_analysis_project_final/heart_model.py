import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import pickle
heart_data=pd.read_csv("C:\\Users\\HP\\Downloads\\heart_2022_no_nans.csv")
heart_data=heart_data.drop_duplicates()
data2=heart_data.copy()
heart_data=heart_data.drop('TetanusLast10Tdap',axis=1)
heart_data=heart_data.drop('State',axis=1)
heart_data = pd.get_dummies(heart_data, columns = ['Sex', 'GeneralHealth',
       'LastCheckupTime', 'PhysicalActivities', 'RemovedTeeth',
       'HadAngina', 'HadStroke', 'HadAsthma',
       'HadSkinCancer', 'HadCOPD', 'HadDepressiveDisorder', 'HadKidneyDisease',
       'HadArthritis', 'HadDiabetes', 'DeafOrHardOfHearing',
       'BlindOrVisionDifficulty', 'DifficultyConcentrating',
       'DifficultyWalking', 'DifficultyDressingBathing', 'DifficultyErrands',
       'SmokerStatus', 'ECigaretteUsage', 'ChestScan', 'RaceEthnicityCategory',
       'AgeCategory', 'AlcoholDrinkers', 'HIVTesting', 'FluVaxLast12', 'PneumoVaxEver',
       'HighRiskLastYear', 'CovidPos'], drop_first=True)
standardScaler = StandardScaler()
columns_for_ft_scaling=['PhysicalHealthDays','MentalHealthDays','SleepHours','HeightInMeters','WeightInKilograms','BMI']

heart_data[columns_for_ft_scaling]=standardScaler.fit_transform(heart_data[columns_for_ft_scaling])
heart_data.loc[heart_data.HadHeartAttack=='No','HadHeartAttack']=0
heart_data.loc[heart_data.HadHeartAttack=='Yes','HadHeartAttack']=1
y=heart_data['HadHeartAttack']
X=heart_data.drop('HadHeartAttack',axis=1)
#split the data into tarining set (70%) and test set (30%)
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.30, random_state = 50)
from sklearn.preprocessing import LabelEncoder

# Initialize the LabelEncoder
label_encoder = LabelEncoder()

# Convert the target variable y_train to numeric labels
y_train_encoded = label_encoder.fit_transform(y_train)

# Convert the target variable y_test to numeric labels (if needed)
y_test_encoded = label_encoder.transform(y_test)
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
logmodel = LogisticRegression()
logmodel.fit(X_train, y_train_encoded)

# Predict the values for the new, unseen data (test set)
pred = logmodel.predict(X_test)

# Finding accuracy using accuracy_score method
logmodel_accuracy = round(metrics.accuracy_score(y_test_encoded, pred) * 100, 2)
print(f"Logistic Regression Model Accuracy: {logmodel_accuracy}%")
from sklearn.metrics import confusion_matrix
conf_mat_logmodel = confusion_matrix(y_test_encoded,pred)
heart_data['Probability_of_Risk'] = (logmodel.predict_proba(heart_data[X_test.columns])[:,1])
with open('heart_model.pkl', 'wb') as model_file:
    pickle.dump(logmodel, model_file)
                                     